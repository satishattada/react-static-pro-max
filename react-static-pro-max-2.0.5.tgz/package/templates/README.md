# Templates

The templates in the directory will get you started. They are designed to be selected when using the ```react-static-pro-max create``` CLI command.

## blank

An absolutely minimal app.

## basic

A Single Page App with multiple pages and a shared navigation component. The pages are automatically routed based on their filename in the pages folder using ```react-router```.

## typescript

The basic template, but with `react-static-pro-max-plugin-typescript` added and configured for you with every component in `.tsx` and absolute paths set up in `tsconfig.json`.

## stress test

A website with a large number of fake routes for testing performance.
